// ============================================================
//  PRODUCT DATA — No prices, premium catalogue
// ============================================================
const categories = [
    {
        name: "Dry Fruits",
        emoji: "🍇",
        products: [
            { name: "Seedless Black Raisins",     weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Raisins_01.jpg/960px-Raisins_01.jpg" },
            { name: "Medjool Dates",               weight: "500g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Dates005.jpg/960px-Dates005.jpg" },
            { name: "Afghan Dried Apricots",       weight: "200g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Ab_food_04.jpg/960px-Ab_food_04.jpg" },
            { name: "Premium Medjool Dates",       weight: "1kg",  img: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/%C5%9Awie%C5%BCy_daktyle_odmiany_MEDJOOL.jpg/960px-%C5%9Awie%C5%BCy_daktyle_odmiany_MEDJOOL.jpg" },
            { name: "Sun-Dried California Prunes", weight: "500g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/Rosales_-_Dried_Prunus_domestica_d.jpg/960px-Rosales_-_Dried_Prunus_domestica_d.jpg" },
        ]
    },
    {
        name: "Exotic Nuts",
        emoji: "🥜",
        products: [
            { name: "Turkish Hazelnuts",             weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Hazelnuts_%28Corylus_avellana%29_-_whole_with_kernels.jpg/960px-Hazelnuts_%28Corylus_avellana%29_-_whole_with_kernels.jpg" },
            { name: "Whole Cashew Nuts (W240)",      weight: "500g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/Cashew_apples.jpg/960px-Cashew_apples.jpg" },
            { name: "Iranian Pistachios",            weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/Pistachio_vera.jpg/960px-Pistachio_vera.jpg" },
            { name: "California Walnuts (Halves)",   weight: "500g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Walnuts_-_whole_and_open_with_halved_kernel.jpg/960px-Walnuts_-_whole_and_open_with_halved_kernel.jpg" },
            { name: "Mamra Almonds",                 weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Almonds_-_in_shell%2C_shell_cracked_open%2C_shelled%2C_blanched.jpg/960px-Almonds_-_in_shell%2C_shell_cracked_open%2C_shelled%2C_blanched.jpg" },
        ]
    },
    {
        name: "Berries",
        emoji: "🫐",
        products: [
            { name: "Dried Blueberries",          weight: "150g", img: "https://upload.wikimedia.org/wikipedia/commons/1/15/Blueberries.jpg" },
            { name: "Freeze-Dried Strawberries",  weight: "100g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Garden_strawberry_%28Fragaria_%C3%97_ananassa%29_single2.jpg/960px-Garden_strawberry_%28Fragaria_%C3%97_ananassa%29_single2.jpg" },
            { name: "Dried Raspberries",          weight: "100g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Raspberry_-_halved_%28Rubus_idaeus%29.jpg/960px-Raspberry_-_halved_%28Rubus_idaeus%29.jpg" },
            { name: "Dried Blackberries",         weight: "150g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/Ripe%2C_ripening%2C_and_green_blackberries.jpg/960px-Ripe%2C_ripening%2C_and_green_blackberries.jpg" },
            { name: "Dried Cranberries",          weight: "200g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Cranberry_bog.jpg/960px-Cranberry_bog.jpg" },
        ]
    },
    {
        name: "Seeds & Superfoods",
        emoji: "🌱",
        products: [
            { name: "Roasted Sunflower Seeds",   weight: "200g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Sunflower_Seeds_Kaldari.jpg/960px-Sunflower_Seeds_Kaldari.jpg" },
            { name: "Pumpkin Seeds",             weight: "200g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Pepita_de_calabaza.jpg/960px-Pepita_de_calabaza.jpg" },
            { name: "Chia Seeds",                weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Seed_of_chia_%28Salvia_hispanica%29Salvia_hispanica_group.jpg/960px-Seed_of_chia_%28Salvia_hispanica%29Salvia_hispanica_group.jpg" },
            { name: "Blue Poppy Seeds",          weight: "100g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Poppy_seeds.jpg/960px-Poppy_seeds.jpg" },
            { name: "Amaranth Seeds",            weight: "500g", img: "https://upload.wikimedia.org/wikipedia/commons/e/eb/Amaranth_und_WW.jpg" },
        ]
    },
    {
        name: "Gourmet Mixes",
        emoji: "🥗",
        products: [
            { name: "Classic Trail Mix",            weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/2021-05-15_04_45_03_A_sample_of_Kirkland_Trail_Mix_in_the_Dulles_section_of_Sterling%2C_Loudoun_County%2C_Virginia.jpg/960px-2021-05-15_04_45_03_A_sample_of_Kirkland_Trail_Mix_in_the_Dulles_section_of_Sterling%2C_Loudoun_County%2C_Virginia.jpg" },
            { name: "Granola & Fruit Bowl Mix",     weight: "300g", img: "https://upload.wikimedia.org/wikipedia/commons/9/94/Granola%2C_yogurt%2C_fruit._%2816696981528%29.jpg" },
            { name: "Muesli Breakfast Mix",          weight: "500g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/da/Dorset_Cereals_muesli.jpg/960px-Dorset_Cereals_muesli.jpg" },
            { name: "Roasted Mixed Nuts",            weight: "250g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Mixed_nuts_small_white1.jpg/960px-Mixed_nuts_small_white1.jpg" },
            { name: "Salted Snack Mix",              weight: "200g", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Chex-Mix-Pile.jpg/960px-Chex-Mix-Pile.jpg" },
        ]
    },
    {
        name: "Premium Gift Hampers",
        emoji: "🎁",
        products: [
            { name: "Festival Dry Fruit Hamper",      weight: "1kg",   img: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&h=600&fit=crop" },
            { name: "Luxury Nut & Berry Hamper",      weight: "800g",  img: "https://images.unsplash.com/photo-1512909006721-3d6018887383?w=600&h=600&fit=crop" },
            { name: "Corporate Delight Hamper",       weight: "1.2kg", img: "https://images.unsplash.com/photo-1513201099705-a9746e1e201f?w=600&h=600&fit=crop" },
            { name: "Wedding Celebration Hamper",     weight: "2kg",   img: "https://images.unsplash.com/photo-1511269366731-cbddd33924f7?w=600&h=600&fit=crop" },
            { name: "Premium Gifting Box (Assorted)", weight: "1.5kg", img: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=600&h=600&fit=crop" },
        ]
    },
    {
        name: "Subscription Boxes",
        emoji: "📦",
        products: [
            { name: "Monthly Nut & Seed Box",          weight: "1kg",   img: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&h=600&fit=crop" },
            { name: "Weekly Snack Surprise Box",       weight: "500g",  img: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=600&h=600&fit=crop" },
            { name: "Quarterly Wellness Bundle",       weight: "3kg",   img: "https://images.unsplash.com/photo-1608686207856-001b95cf60ca?w=600&h=600&fit=crop" },
            { name: "Bi-Weekly Dry Fruit Box",         weight: "750g",  img: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&h=600&fit=crop" },
            { name: "Annual Premium Membership Box",   weight: "1.5kg", img: "https://images.unsplash.com/photo-1512909006721-3d6018887383?w=600&h=600&fit=crop" },
        ]
    },
];

// ============================================================
//  GENERATE PRODUCT SECTIONS
// ============================================================
function generateProducts() {
    const container = document.getElementById('dynamic-product-sections');
    if (!container) return;
    container.innerHTML = '';

    categories.forEach(category => {
        const section = document.createElement('section');
        section.className = 'product-category-section';
        // Store category name as data attribute for filtering
        section.dataset.category = category.name;
        // Unique ID for scroll target
        section.id = 'cat-section-' + category.name.replace(/[^a-z0-9]/gi, '-').toLowerCase();

        const title = document.createElement('h2');
        title.innerHTML = `${category.emoji} ${category.name}`;
        section.appendChild(title);

        const grid = document.createElement('div');
        grid.className = 'product-grid';

        category.products.forEach(product => {
            // No price shown — enquiry-based only
            const cardHTML = `
                <div class="product-card">
                    <div class="product-img-wrapper">
                        <img src="${product.img}" loading="lazy" alt="${product.name}">
                        <div class="card-badge">Premium</div>
                    </div>
                    <div class="time-tag">
                        <i class='bx bxs-stopwatch'></i> Express Delivery
                    </div>
                    <h3 class="product-title">${product.name}</h3>
                    <div class="product-weight">${product.weight}</div>
                    <div class="product-bottom">
                        <button class="enquire-btn" onclick="handleEnquire('${product.name}', '${category.name}')">
                            <i class='bx bxl-whatsapp'></i> Enquire
                        </button>
                        <button class="buy-now-btn"
                            data-name="${product.name}"
                            data-weight="${product.weight}"
                            data-img="${product.img}"
                            data-category="${category.name}"
                            onclick="openBuyModal(this)">
                            <i class='bx bx-cart-add'></i> Buy Now
                        </button>
                    </div>
                </div>
            `;
            grid.innerHTML += cardHTML;
        });

        section.appendChild(grid);
        container.appendChild(section);
    });
}

// ============================================================
//  CATEGORY FILTER — scroll to section + highlight category tile
// ============================================================
function filterCategory(catName, tileEl) {
    // Update active state on tiles
    document.querySelectorAll('.cat-item').forEach(t => t.classList.remove('active-cat'));
    if (tileEl) tileEl.classList.add('active-cat');

    const sections = document.querySelectorAll('.product-category-section');

    if (catName === 'all') {
        // Show all sections
        sections.forEach(s => {
            s.style.display = '';
        });
        // Scroll to first section
        const first = document.getElementById('dynamic-product-sections');
        if (first) first.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }

    // Show only matching section, hide others
    let targetSection = null;
    sections.forEach(s => {
        if (s.dataset.category === catName) {
            s.style.display = '';
            targetSection = s;
        } else {
            s.style.display = 'none';
        }
    });

    if (targetSection) {
        setTimeout(() => {
            targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 80);
    }
}

// ============================================================
//  ENQUIRE HANDLER (WhatsApp enquiry)
// ============================================================
function handleEnquire(productName, categoryName) {
    const msg = encodeURIComponent(
        `Hi Nutritiva! I'd like to enquire about:\n\n` +
        `📦 Product: ${productName}\n` +
        `📁 Category: ${categoryName}\n\n` +
        `Could you please share the pricing, availability and packaging details? Thank you!`
    );
    window.open(`https://wa.me/919999999999?text=${msg}`, '_blank');
}

// ============================================================
//  INIT
// ============================================================
document.addEventListener('DOMContentLoaded', generateProducts);
