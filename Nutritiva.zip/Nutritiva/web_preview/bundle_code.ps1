$outputPath = ".\Nutritiva_Source_Code.md"

# Clear the file if it exists
if (Test-Path $outputPath) { Remove-Item $outputPath }

# Add Title
Add-Content -Path $outputPath -Value "# Nutritiva Project Source Code`n"

# Process index.html
Add-Content -Path $outputPath -Value "## index.html"
Add-Content -Path $outputPath -Value "``````html"
Get-Content -Path ".\index.html" | Add-Content -Path $outputPath
Add-Content -Path $outputPath -Value "```````n"

# Process styles.css
Add-Content -Path $outputPath -Value "## styles.css"
Add-Content -Path $outputPath -Value "``````css"
Get-Content -Path ".\styles.css" | Add-Content -Path $outputPath
Add-Content -Path $outputPath -Value "```````n"

# Process products.js
Add-Content -Path $outputPath -Value "## products.js"
Add-Content -Path $outputPath -Value "``````javascript"
Get-Content -Path ".\products.js" | Add-Content -Path $outputPath
Add-Content -Path $outputPath -Value "```````n"

Write-Host "✅ Successfully generated Nutritiva_Source_Code.md!"
Write-Host "You can now open Nutritiva_Source_Code.md and print it to PDF."
